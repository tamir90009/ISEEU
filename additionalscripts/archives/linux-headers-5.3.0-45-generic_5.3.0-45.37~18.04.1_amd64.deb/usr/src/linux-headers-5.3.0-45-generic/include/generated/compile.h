/* This file is auto generated, version 37~18.04.1-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#37~18.04.1-Ubuntu SMP Fri Mar 27 15:58:10 UTC 2020"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lcy01-amd64-027"
#define LINUX_COMPILER "gcc version 7.5.0 (Ubuntu 7.5.0-3ubuntu1~18.04)"
