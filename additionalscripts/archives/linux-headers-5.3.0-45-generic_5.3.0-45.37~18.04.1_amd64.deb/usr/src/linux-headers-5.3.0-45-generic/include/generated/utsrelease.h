#define UTS_RELEASE "5.3.0-45-generic"
#define UTS_UBUNTU_RELEASE_ABI 45
