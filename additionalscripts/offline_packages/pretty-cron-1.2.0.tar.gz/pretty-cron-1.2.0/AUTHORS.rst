=======
Credits
=======

Development Lead
----------------

* Adam Johnson <me@adamj.eu>

Original Author
---------------

Originally created by Ben Davis at https://github.com/ben-davis/prettycron .

Contributors
------------

* Julio Bondia <julio.bondia13@gmail.com>
* Mike Readhead <github@0xdb.co.uk>
